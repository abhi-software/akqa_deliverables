package com.akqa.ChequeWritingWebService.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.akqa.ChequeWritingWebService.model.Cheque;
import com.akqa.ChequeWritingWebService.model.ChequeWritingService;

@Controller
public class ChequeWriterController {

	@GetMapping("/")
	public String showForm(Model m) {
		m.addAttribute("cheque", new Cheque());
		return "index";

	}

	@PostMapping("/result")
	public String submitForm(@ModelAttribute("cheque") Cheque cheque, BindingResult result) {
		// get the amount entered by user in index.html form
		String amt = cheque.getCheqAmount();

		// store converted amount in words (dollars and cents)
		String amtInWords = ChequeWritingService.convertMoneyIntoWords(amt);
	
		// set amount in the cheque object
		cheque.setCheqAmount(amtInWords);

		// show the result to the user after conversion
		return "result_success";
	}


}

package com.akqa.ChequeWritingWebService.model;

public class Cheque {
	
	private String cheqName;
	private String cheqAmount;
	
	public String getCheqName() {
		return cheqName;
	}
	public void setCheqName(String cheqName) {
		this.cheqName = cheqName;
	}
	public String getCheqAmount() {
		return cheqAmount;
	}
	public void setCheqAmount(String cheqAmount) {
		this.cheqAmount = cheqAmount;
	}
	@Override
	public String toString() {
		return "Cheque [cheqName=" + cheqName + ", cheqAmount=" + cheqAmount + "]";
	}
	
	
}

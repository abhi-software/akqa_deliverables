package com.akqa.ChequeWritingWebService.model;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ChequeWritingServiceTest {

	@Test
	void testConvertMoneyIntoWords1() {
		String actual = ChequeWritingService.convertMoneyIntoWords("123.45");
		String expected = "ONE HUNDRED TWENTY THREE DOLLARS AND FORTY FIVE CENTS";
		assertEquals(expected, actual);
	}
	
	@Test
	void testConvertMoneyIntoWords2() {
		String actual = ChequeWritingService.convertMoneyIntoWords("89");
		String expected = "EIGHTY NINE DOLLARS";
		assertEquals(expected, actual);
	}

}
